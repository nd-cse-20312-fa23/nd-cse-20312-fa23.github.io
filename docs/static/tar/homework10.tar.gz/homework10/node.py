#!/usr/bin/env python3

from dataclasses import dataclass
from typing import Optional

# Class

@dataclass
class Node:
    symbol: str
    value:  int = 0
    left:   Optional['Node'] = None
    right:  Optional['Node'] = None

    def __gt__(self, other: 'Node') -> bool:
        ''' Compare the current Node's value to the other's value.

        >>> Node('aa', 1) > Node('b', 0)
        True

        >>> Node('aa', 0) > Node('b', 0)
        True
        '''
        pass

# Functions

def walk(node: Optional[Node], codeword: str='') -> dict:
    '''
    Construct the Huffman codewords by walking the binary tree.

    >>> tree = Node('', 6, Node('A', 3), Node('', 3, Node('C', 1), Node('B', 2)))
    >>> walk(tree)
    {'A': '0', 'C': '10', 'B': '11'}
    '''
    pass

# vim: set sts=4 sw=4 ts=8 expandtab ft=python:
