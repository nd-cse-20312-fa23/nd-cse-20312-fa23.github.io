#!/usr/bin/env python3

from dataclasses import dataclass, field

# Class

@dataclass
class PriorityQueue:
    data: list = field(default_factory=list)

    def _bubble_up(self, index: int) -> None:
        ''' Bubble up value starting at index.

        >>> pq = PriorityQueue([2, 3, 1])
        >>> pq._bubble_up(2)
        >>> pq.data
        [1, 3, 2]
        '''
        pass

    def push(self, value) -> None:
        ''' Add a value to the Priority Queue.

        >>> pq = PriorityQueue([2, 3])
        >>> pq.push(1)
        >>> pq.data
        [1, 3, 2]
        '''
        pass

    def _find_smallest_child(self, index: int) -> int:
        ''' Determine which child of the node at specified index has the
        smallest value.

        >>> pq = PriorityQueue([3, 2, 1])
        >>> pq._find_smallest_child(0)
        2
        '''
        pass

    def _bubble_down(self, index: int) -> None:
        ''' Bubble down value starting at index.

        >>> pq = PriorityQueue([3, 2])
        >>> pq._bubble_down(0)
        >>> pq.data
        [2, 3]
        '''
        pass

    def pop(self):
        ''' Remove and return largest value in the Priority Queue.

        >>> pq = PriorityQueue([1, 2, 3])
        >>> pq.pop()
        1
        >>> pq.data
        [2, 3]
        '''
        pass

    def __len__(self) -> int:
        ''' Return the number of values in the Priority Queue.

        >>> pq = PriorityQueue([1, 2, 3])
        >>> len(pq)
        3
        '''
        pass

# Functions

def left_index(index: int) -> int:
    ''' Return index of left child

    >>> left_index(0)
    1
    '''
    pass

def right_index(index: int) -> int:
    ''' Return index of right child

    >>> right_index(0)
    2
    '''
    pass

def parent_index(index: int) -> int:
    ''' Return index of parent

    >>> parent_index(1)
    0
    '''
    pass

# vim: set sts=4 sw=4 ts=8 expandtab ft=python:
