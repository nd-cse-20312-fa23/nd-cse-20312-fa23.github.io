/* unit_stack.c: Stack Unit Test */

#include "ds/stack.h"

#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Constants */

/* Tests */

int test_00_stack_create() {
    Stack *stack = stack_create();
    assert(stack->capacity == ARRAY_DEFAULT_CAPACITY);
    assert(stack->size     == 0);

    array_delete(stack);
    return EXIT_SUCCESS;
}

int test_01_stack_delete() {
    Stack *stack = stack_create();
    assert(stack->capacity == ARRAY_DEFAULT_CAPACITY);
    assert(stack->size     == 0);

    stack_delete(stack);
    return EXIT_SUCCESS;
}

int test_02_stack_empty() {
    Stack *stack = stack_create();
    assert(stack->capacity == ARRAY_DEFAULT_CAPACITY);
    assert(stack->size     == 0);

    assert(stack_empty(stack));
    stack->size++;
    assert(!stack_empty(stack));

    stack_delete(stack);
    return EXIT_SUCCESS;
}

int test_03_stack_top() {
    Stack *stack = stack_create();
    assert(stack->capacity == ARRAY_DEFAULT_CAPACITY);
    assert(stack->size     == 0);

    for (size_t index = 0; index < ARRAY_DEFAULT_CAPACITY; index++) {
        array_append(stack, index);
        assert(stack_top(stack) == index);
    }

    stack_delete(stack);
    return EXIT_SUCCESS;
}

int test_04_stack_push() {
    Stack *stack = stack_create();
    assert(stack->capacity == ARRAY_DEFAULT_CAPACITY);
    assert(stack->size     == 0);

    for (size_t index = 0; index < ARRAY_DEFAULT_CAPACITY; index++) {
        stack_push(stack, index);
        assert(stack_top(stack) == index);
    }

    stack_delete(stack);
    return EXIT_SUCCESS;
}

int test_05_stack_pop() {
    Stack *stack = stack_create();
    assert(stack->capacity == ARRAY_DEFAULT_CAPACITY);
    assert(stack->size     == 0);

    for (size_t index = 0; index < ARRAY_DEFAULT_CAPACITY; index++) {
        stack_push(stack, index);
        assert(stack_top(stack) == index);
    }

    size_t count = 0;
    while (!stack_empty(stack)) {
        assert(stack_pop(stack) == ARRAY_DEFAULT_CAPACITY - count - 1);
        count++;
    }

    stack_delete(stack);
    return EXIT_SUCCESS;
}

/* Main Execution */

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s NUMBER\n\n", argv[0]);
        fprintf(stderr, "Where NUMBER is right of the following:\n");
        fprintf(stderr, "    0  Test stack_create\n");
        fprintf(stderr, "    1  Test stack_delete\n");
        fprintf(stderr, "    2  Test stack_empty\n");
        fprintf(stderr, "    3  Test stack_top\n");
        fprintf(stderr, "    4  Test stack_push\n");
        fprintf(stderr, "    5  Test stack_pop\n");
        return EXIT_FAILURE;
    }   

    int number = atoi(argv[1]);
    int status = EXIT_FAILURE;

    switch (number) {
        case 0:  status = test_00_stack_create(); break;
        case 1:  status = test_01_stack_delete(); break;
        case 2:  status = test_02_stack_empty(); break;
        case 3:  status = test_03_stack_top(); break;
        case 4:  status = test_04_stack_push(); break;
        case 5:  status = test_05_stack_pop(); break;
        default: fprintf(stderr, "Unknown NUMBER: %d\n", number); break;
    }
    
    return status;
}

/* vim: set sts=4 sw=4 ts=8 expandtab ft=c: */
