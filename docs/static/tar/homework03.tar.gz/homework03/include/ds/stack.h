/* stack.h: Stack */

#pragma once

#include "array.h"

/* Structures */

typedef Array Stack;

/* Functions */

Stack	*stack_create();
void	 stack_delete(Stack *stack);

bool	 stack_empty(Stack *stack);
int64_t	 stack_top(Stack *stack);

void	 stack_push(Stack *stack, int64_t value);
int64_t	 stack_pop(Stack *stack);
