/* array.h: Dynamic Array */

#pragma once

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

/* Structures */

typedef struct {
    int64_t *data;
    size_t   capacity;
    size_t   size;
} Array;

/* Constants */

extern const size_t ARRAY_DEFAULT_CAPACITY;

/* Functions */

Array	*array_create(size_t capacity);
void	 array_delete(Array *array);

int64_t	 array_at(Array *array, ssize_t index);

void	 array_resize(Array *array, size_t capacity);

void	 array_append(Array *array, int64_t value);
int64_t	 array_pop(Array *array, ssize_t index);
