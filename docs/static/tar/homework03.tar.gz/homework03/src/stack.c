/* stack.c: Stack */

#include "ds/stack.h"

#include <assert.h>

/* Functions */

/**
 * Create a stack.
 *
 * @return  A new stack (must be deleted later).
 **/
Stack*	stack_create() {
    // TODO
    return NULL;
}

/**
 * Delete stack and its contents.
 *
 * @param   stack	Pointer to stack.
 **/
void	stack_delete(Stack *stack) {
    // TODO
}

/**
 * Return whether or not the stack is empty.
 *
 * @param   stack	Pointer to stack.
 * @return  Whether or not the stack is empty.
 **/
bool	stack_empty(Stack *stack) {
    // TODO
}

/**
 * Return value at the top of stack.
 * @param   stack	Pointer to stack.
 * @return  Value at the top of stack.
 **/
int64_t stack_top(Stack *stack) {
    // TODO
    return 0;
}

/**
 * Add specified value to the top of stack.
 *
 * @param   stack	Pointer to stack.
 * @param   value	Value to add to top of stack.
 **/
void	stack_push(Stack *stack, int64_t value) {
    // TODO
}

/**
 * Return value at the top of stack.
 *
 * @param   stack	Pointer to stack.
 * @return  Value at the top of stack.
 **/
int64_t	stack_pop(Stack *stack) {
    // TODO
}
