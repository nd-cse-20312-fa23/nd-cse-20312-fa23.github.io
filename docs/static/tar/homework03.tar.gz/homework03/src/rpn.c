/* rpn.c: Reverse Polish Notation Calculator */

#include "ds/stack.h"

#include <errno.h>
#include <stdio.h>
#include <string.h>

/* Constants */

const char *WHITESPACE = " \t\r\n";

/* Functions */

/**
 * Evaluate the given RPN expression using a stack.
 *
 * @param   expression	String containing RPN expression.
 * @return  Result of evaluating RPN expression using stack.
 **/
int64_t evaluate_expression(char *expression) {
    // TODO
    return 0;
}

/* Main Execution */

int main(int argc, char *argv[]) {
    // TODO: For each line in standard input, evaluate the RPN expression
    return EXIT_SUCCESS;
}
