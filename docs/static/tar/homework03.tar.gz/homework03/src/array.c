/* array.c: Dynamic Array */

#include "ds/array.h"

#include <assert.h>
#include <string.h>

/* Constants */

const size_t ARRAY_DEFAULT_CAPACITY = 1<<3;

/* Functions */

/**
 * Allocate and initialize a new dynamic array with specified capacity.
 *
 *  If a capacity of 0 is specified, then use ARRAY_DEFAULT_CAPACITY.
 *
 * @param   capacity	Total number of elements in new dynamic array.
 * @return  New dynamic array (must be deleted later).
 **/
Array*	array_create(size_t capacity) {
    // TODO
    return NULL;
}

/**
 * Release internal data of dynamic array and the array itself.
 *
 * @param   array	Pointer to dynamic array.
 **/
void	array_delete(Array *array) {
    // TODO
}

/**
 * Return value in dynamic array at specified index.
 *
 * Note: If index is negative, then offset it relative to size of array.
 *  
 * @param   array	Pointer to dynamic array.
 * @param   index	Index of element.
 * @return  Value at the specified index in the array.
 **/
int64_t	array_at(Array *array, ssize_t index) {
    // TODO
    return 0;
}

/**
 * Resize the array by the specified capacity.
 *
 * @param   array	Pointer to dynamic array.
 * @param   capacity	New capacity for resized array.
 **/
void	array_resize(Array *array, size_t capacity) {
    // TODO
}

/**
 * Add new value to the end of the dynamic array.
 *
 * Note: Resize array if necessary.
 *
 * @param   array	Pointer to dynamic array.
 * @param   value	New value to add.
 **/
void	array_append(Array *array, int64_t value) {
    // TODO
}

/**
 * Remove element from array at specified index and return its value.
 *
 * Note: If index is negative, then offset it relative to size of array.
 *
 * @param   array	Pointer to dynamic array.
 * @param   index	Index of element to remove.
 * @return  Value associated with removed element.
 **/
int64_t	array_pop(Array *array, ssize_t index) {
    // TODO
    return 0;
}
