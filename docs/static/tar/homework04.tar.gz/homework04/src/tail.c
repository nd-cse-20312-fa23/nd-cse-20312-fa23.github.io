/* tail.c: Output the last part of files */

#include "ds/queue.h"

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Functions */

void usage(int status) {
    fprintf(stderr, "usage: tail [-n limit ]\n");
    exit(status);
}

/* Main Execution */

int main(int argc, char *argv[]) {
    // TODO: Parse command-line arguments

    // TODO: Use Queue to implement tail
    return EXIT_SUCCESS;
}
