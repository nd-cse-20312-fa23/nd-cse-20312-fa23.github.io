/* tac.c: concatenate and print files in reverse */

#include "ds/queue.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Main Execution */

int main(int argc, char *argv[]) {
    // TODO: Use Queue to implement tac
    return EXIT_SUCCESS;
}
