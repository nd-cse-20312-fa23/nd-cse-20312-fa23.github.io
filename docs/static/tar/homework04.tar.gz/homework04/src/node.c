/* node.c: Node Structure */

#include "ds/node.h"

#include <stdlib.h>
#include <string.h>

/* Functions */

/**
 * Create a Node structure.
 *
 * @param   data    String.
 * @param   next    Pointer to next Node structure.
 * @param   prev    Pointer to previous Node structure.
 * @return  Pointer to a new Node structure (must be deleted later).
 **/
Node *	node_create(const char *data, Node *next, Node *prev) {
    // TODO
    return NULL;
}

/**
 * Delete Node structure and its contents.
 *
 * @param   n	    Pointer to Node structure.
 **/
void	node_delete(Node *n) {
    // TODO
}
