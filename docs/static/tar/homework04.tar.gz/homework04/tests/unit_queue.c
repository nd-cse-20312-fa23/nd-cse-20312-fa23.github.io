/* unit_queue.c: Queue Structure Unit Test */

#include "ds/queue.h"

#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

/* Constants */

const char *STRINGS[] = {
    "I have lost the feeling that I thought I'd never lose",
    "Now where am I going?",
    "At what cost, the feeling that I thought I'd never lose",
    "It is barbaric",
    "You have lost",
    "The feeling that you thought you'd never lose",
    "Now wherе are you going, darling?",
    "At what cost, the feeling that you thought you'd nevеr lose",
    "And it is barbaric",
    NULL
};

/* Macros */

#define min(a, b)   (((a) < (b)) ? (a) : (b))

/* Tests */

int test_00_queue_create() {
    Queue *q1 = queue_create(0);
    assert(q1);
    assert(q1->sentinel.data == NULL);
    assert(q1->sentinel.next == &q1->sentinel);
    assert(q1->sentinel.prev == &q1->sentinel);
    assert(q1->capacity == 0);
    assert(q1->size == 0);
    free(q1);
    
    Queue *q2 = queue_create(sizeof(STRINGS));
    assert(q2);
    assert(q2->sentinel.data == NULL);
    assert(q2->sentinel.next == &q2->sentinel);
    assert(q2->sentinel.prev == &q2->sentinel);
    assert(q2->capacity == sizeof(STRINGS));
    assert(q2->size == 0);
    free(q2);
    return EXIT_SUCCESS;
}

int test_01_queue_delete() {
    Queue *q1 = queue_create(0);
    assert(q1);
    assert(q1->sentinel.data == NULL);
    assert(q1->sentinel.next == &q1->sentinel);
    assert(q1->sentinel.prev == &q1->sentinel);
    assert(q1->capacity == 0);
    assert(q1->size == 0);
    queue_delete(q1);
    
    Queue *q2 = queue_create(sizeof(STRINGS));
    assert(q2);
    assert(q2->sentinel.data == NULL);
    assert(q2->sentinel.next == &q2->sentinel);
    assert(q2->sentinel.prev == &q2->sentinel);
    assert(q2->capacity == sizeof(STRINGS));
    assert(q2->size == 0);
    queue_delete(q2);
    
    Queue *q3 = queue_create(sizeof(STRINGS));
    assert(q3);
    assert(q3->sentinel.data == NULL);
    assert(q3->sentinel.next == &q3->sentinel);
    assert(q3->sentinel.prev == &q3->sentinel);
    assert(q3->capacity == sizeof(STRINGS));
    assert(q3->size == 0);

    Node *n0 = node_create(STRINGS[0], NULL, &q3->sentinel);
    Node *n1 = node_create(STRINGS[1], NULL, n0);
    Node *n2 = node_create(STRINGS[2], NULL, n1);
    Node *n3 = node_create(STRINGS[3], NULL, n2);
    n0->next = n1;
    n1->next = n2;
    n2->next = n3;
    n3->next = &q3->sentinel;
    q3->sentinel.next = n0;
    q3->sentinel.prev = n3;

    queue_delete(q3);
    return EXIT_SUCCESS;
}

int test_02_queue_push() {
    Queue *q = queue_create(0);
    
    for (const char **s = STRINGS; *s; s++) {
        queue_push(q, *s);
        assert(strcmp(*s, q->sentinel.prev->data) == 0);
        assert(q->size == s - STRINGS + 1);
    }
    
    queue_delete(q);
    
    return EXIT_SUCCESS;
}

int test_03_queue_pop() {
    Queue *q = queue_create(0);
    
    for (const char **s = STRINGS; *s; s++) {
        queue_push(q, *s);
        assert(strcmp(*s, q->sentinel.prev->data) == 0);
        assert(q->size == s - STRINGS + 1);
    }
    
    for (const char **s = STRINGS; *s; s++) {
        char *v = queue_pop(q);
        assert(strcmp(*s, v) == 0);
        assert(q->size == sizeof(STRINGS)/sizeof(char *) - 1 - (s - STRINGS + 1));
        free(v);
    }
    
    queue_delete(q);
    return EXIT_SUCCESS;
}

int test_04_queue_capacity() {
    Queue *q = queue_create(4);
    
    for (const char **s = STRINGS; *s; s++) {
        queue_push(q, *s);
        assert(strcmp(*s, q->sentinel.prev->data) == 0);
        assert(q->size == min(s - STRINGS + 1, q->capacity));
    }

    queue_delete(q);
    return EXIT_SUCCESS;
}

int test_05_queue_empty() {
    Queue *q = queue_create(4);
    
    assert(queue_empty(q));
    for (const char **s = STRINGS; *s; s++) {
        queue_push(q, *s);
        assert(strcmp(*s, q->sentinel.prev->data) == 0);
        assert(q->size == min(s - STRINGS + 1, q->capacity));
        assert(!queue_empty(q));
    }

    while (!queue_empty(q)) {
        free(queue_pop(q));
    }

    assert(queue_empty(q));
    queue_delete(q);
    return EXIT_SUCCESS;
}

int test_06_queue_dump() {
    Queue *q = queue_create(0);
    
    assert(queue_empty(q));
    for (const char **s = STRINGS; *s; s++) {
        queue_push(q, *s);
        assert(strcmp(*s, q->sentinel.prev->data) == 0);
        assert(q->size == s - STRINGS + 1);
        assert(!queue_empty(q));
    }

    char tmp_path[BUFSIZ] = "/tmp/unit_queue_XXXXXXX";
    int fd = mkstemp(tmp_path);
    if (fd < 0) {
        return EXIT_FAILURE;
    }
    FILE *fs = fdopen(fd, "r+");
    if (!fs) {
        return EXIT_FAILURE;
    }
    unlink(tmp_path);

    queue_dump(q, fs);
    rewind(fs);

    char buffer[BUFSIZ];
    while (fgets(buffer, BUFSIZ, fs)) {
        char *v = queue_pop(q);
        buffer[strlen(buffer) - 1] = 0;
        assert(strcmp(buffer, v) == 0);
        free(v);
    }

    queue_delete(q);
    return EXIT_SUCCESS;
}

int test_07_queue_reverse() {
    Queue *q = queue_create(0);
    
    assert(queue_empty(q));
    for (const char **s = STRINGS; *s; s++) {
        queue_push(q, *s);
        assert(strcmp(*s, q->sentinel.prev->data) == 0);
        assert(q->size == s - STRINGS + 1);
        assert(!queue_empty(q));
    }

    queue_reverse(q);

    for (ssize_t i = sizeof(STRINGS)/sizeof(char *) - 2; i >= 0; i--) {
        char *v = queue_pop(q);
        assert(strcmp(STRINGS[i], v) == 0);
        assert(q->size == i);
        free(v);
    }

    assert(queue_empty(q));
    queue_delete(q);
    return EXIT_SUCCESS;
}

/* Main Execution */

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s NUMBER\n\n", argv[0]);
        fprintf(stderr, "Where NUMBER is right of the following:\n");
        fprintf(stderr, "    0  Test queue_create\n");
        fprintf(stderr, "    1  Test queue_delete\n");
        fprintf(stderr, "    2  Test queue_push\n");
        fprintf(stderr, "    3  Test queue_pop\n");
        fprintf(stderr, "    4  Test queue_capacity\n");
        fprintf(stderr, "    5  Test queue_empty\n");
        fprintf(stderr, "    6  Test queue_dump\n");
        fprintf(stderr, "    7  Test queue_reverse\n");
        return EXIT_FAILURE;
    }   

    int number = atoi(argv[1]);
    int status = EXIT_FAILURE;

    switch (number) {
        case 0:  status = test_00_queue_create(); break;
        case 1:  status = test_01_queue_delete(); break;
        case 2:  status = test_02_queue_push(); break;
        case 3:  status = test_03_queue_pop(); break;
        case 4:  status = test_04_queue_capacity(); break;
        case 5:  status = test_05_queue_empty(); break;
        case 6:  status = test_06_queue_dump(); break;
        case 7:  status = test_07_queue_reverse(); break;
        default: fprintf(stderr, "Unknown NUMBER: %d\n", number); break;
    }
    
    return status;
}

/* vim: set sts=4 sw=4 ts=8 expandtab ft=c: */
