/* node.h: Node Structure */

#pragma once

/* Structures */

typedef struct Node Node;
struct Node {
    char *data;	    // String value
    Node *next;	    // Pointer to next Node
    Node *prev;	    // Pointer to previous Node
};

/* Functions */

Node *	node_create(const char *data, Node *next, Node *prev);
void	node_delete(Node *n);
