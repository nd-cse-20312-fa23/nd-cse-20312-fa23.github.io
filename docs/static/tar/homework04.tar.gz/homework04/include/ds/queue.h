/* queue.h: Queue Structure */

#pragma once

#include "ds/node.h"

#include <stdbool.h>
#include <stdio.h>

/* Structures */

typedef struct {
    Node   sentinel;	    // Sentinel Node
    size_t capacity;	    // Capacity or maximum size of Queue
    size_t size;	    // Current size of Queue (how many Nodes)
} Queue;

/* Functions */

Queue *	queue_create(size_t capacity);
void	queue_delete(Queue *q);

void	queue_push(Queue *q, const char *s);
char *	queue_pop(Queue *q);

bool	queue_empty(Queue *q);

void	queue_dump(Queue *q, FILE *s);

void	queue_reverse(Queue *q);
