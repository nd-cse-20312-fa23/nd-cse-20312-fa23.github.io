/* string.h: C-Strings */

#pragma once

#include <stdlib.h>

/* Functions */

void	string_chomp(char *s);
char**	string_split(char *s, char delim);
void	strings_free(char **sv);
size_t	strings_size(char **sv);
char*	strings_join(char **sv, char delim);
