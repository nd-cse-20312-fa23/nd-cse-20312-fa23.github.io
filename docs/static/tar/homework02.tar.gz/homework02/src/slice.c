/* slice.c: Slice Utility */

#include "ds/string.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Functions */

/**
 * Display usage message and exits with given status.
 *
 * @param   status  Exit status
 **/
void	usage(int status) {
    fprintf(stderr, "Usage: slice -d DELIMITER -f FIELDS\n");
    exit(status);
}

/**
 * Convert string of field numbers into an array of indices (ie. integers).
 *
 *  string_to_fields("1,3,5") -> {0, 2, 4, -1}
 *
 * Note: the array of integers is terminated by -1.
 *
 * @param   s	String of field numbers (separated by comma)
 * @return  New array of integers (must be freed later)
 **/
int *	string_to_fields(char *s) {
    // TODO: Split string into field numbers (by comma)

    // TODO: Determine how many field numbers we have and allocate an array of
    // integers with the corresponding number of elements

    // TODO: Copy each field string to the array of integers by converting the
    // string into an integer

    // TODO: Place sentinel at the end of array
    return NULL;
}

/**
 * Slice the string based on the delimiter and the chosen fields.
 *
 *  slice_line("a,b,c", ',', {0, 2, -1}) -> "a,c"
 *
 * @param   line    String to slice
 * @param   delim   Delimiter to split string by
 * @param   fields  Array of indices indicating which fields to print
 **/
void	slice_line(char *line, char delim, int *fields) {
    // TODO: Split line into array of strings by specified delimiter

    // TODO: Determine how many strings we have and allocate an array of
    // strings with the corresponding number of elements

    // TODO: Copy each selected string to the new array of strings by updating
    // the current selected element to point to the element in the original
    // strings array corresponding to the current field number

    // TODO: Join the selected strings by the specified delimiter and print out
    // the result
}

/* Main Execution */

int main(int argc, char *argv[]) {
    char  delimiter     = 0;
    char *fields_string = NULL;
    int   argind        = 1;

    // Parse command-line arguments
    while (argind < argc && strlen(argv[argind]) > 1 && argv[argind][0] == '-') {
    	char *argument = argv[argind++];
    	switch (argument[1]) {
	    case 'd': delimiter     = argv[argind++][0]; break;
	    case 'f': fields_string = argv[argind++]   ; break;
	    case 'h': usage(0); break;
	    default:  usage(1); break;
	}
    }

    if (!delimiter || !fields_string) {
    	usage(1);
    }

    // TODO: Slice each line from standard input
    return EXIT_SUCCESS;
}
