/* string.h C-Strings */

#include "ds/string.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Functions */

/**
 * Remove trailing newline from string (if it exists).
 *
 *  string_chomp("abc\n") -> "abc"
 *
 * @param   s	    String to chomp
 **/
void	string_chomp(char *s) {
    // TODO: Remove trailing newline from string
}

/**
 * Split string by delimiter character into a new array of strings.
 *
 *  string_split("a,b,c", ',') -> {"a", "b", c", NULL}
 *
 * Note: the array of strings is terminated by a NULL pointer.
 *
 * @param   s	    String to split
 * @param   delim   Delimiter to split string by
 * @return  New array of strings (must be freed later)
 **/
char**	string_split(char *s, char delim) {
    // TODO: Count the number of strings we will have after splitting

    // TODO: Allocate array of strings (+1 for NULL pointer delimiter)

    // TODO: Scan string and copy words to array of strings
    return NULL;
}

/**
 * Release all the words in array of strings and the array itself.
 *
 * @param   sv	    Array of strings (terminated by NULL pointer)
 **/
void	strings_free(char **sv) {
    // TODO: Release each string in the array and then the array itself
}

/**
 * Return the size of the array of strings (ie. number of strings).
 *
 *  strings_size({"a", "b", "c", NULL}) -> 3
 *
 * @param   sv	    Array of strings (terminated by NULL pointer)
 * @return  Size of the array of strings
 **/
size_t	strings_size(char **sv) {
    // TODO: Count the number of strings in array and return the count
    return 0;
}

/**
 * Combine all the strings in the array of strings into one single string where
 * each string is separated by the specified delimiter.
 *
 * @param   sv	    Array of strings (terminated by NULL pointer)
 * @param   delim   Delimiter used to separate each pair of strings
 *
 * @return  String with all the words in array separated by delimiter (must be
 * freed later)
 **/
char *	strings_join(char **sv, char delim) {
    // TODO: Allocate and copy first word into string we are building

    // TODO: For remaining words, append delimiter and next word to the string
    // we are building
    return NULL;
}
