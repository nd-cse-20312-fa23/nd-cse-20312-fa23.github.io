/* unit_string.c: C-Strings Unit Test */

#include "ds/string.h"

#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Constants */
    
static char STRING0[] = "string";
static char STRING1[] = "data structures";
static char STRING2[] = "to infinity and beyond";
static char STRING3[] = "harry,potter,and,the,goblet,of,fire";

/* Macros */

#define streq(a, b) (strcmp(a, b) == 0)

#define test_01_string_split_case(_s, _delim) \
    do { \
	char  *s  = strdup(_s); \
	char **sv = string_split(s, *(_delim)); \
	size_t si = 0; \
	assert(sv); \
	for (char *word = strtok(_s, _delim); word; word = strtok(NULL, _delim)) { \
	    assert(streq(sv[si], word)); \
	    free(sv[si++]); \
	} \
	assert(sv[si] == NULL); \
	free(sv); \
	free(s); \
    } while (0);

#define test_02_strings_free_case(_s, _delim) \
    do { \
	char  *s  = strdup(_s); \
	char **sv = string_split(s, *(_delim)); \
	size_t si = 0; \
	assert(sv); \
	for (char *word = strtok(_s, _delim); word; word = strtok(NULL, _delim)) { \
	    assert(streq(sv[si++], word)); \
	} \
	assert(sv[si] == NULL); \
	strings_free(sv); \
	free(s); \
    } while (0);

#define test_03_strings_size_case(_s, _delim) \
    do { \
	char  *s  = strdup(_s); \
	char **sv = string_split(s, *(_delim)); \
	size_t si = 0; \
	assert(sv); \
	for (char *word = strtok(_s, _delim); word; word = strtok(NULL, _delim)) { \
	    assert(streq(sv[si++], word)); \
	} \
	assert(sv[si] == NULL); \
	assert(strings_size(sv) == si); \
	strings_free(sv); \
	free(s); \
    } while (0);

#define test_04_strings_join_case(_s, _delim) \
    do { \
	char  *s  = strdup(_s); \
	char **sv = string_split(s, *(_delim)); \
	assert(sv); \
	char  *j  = strings_join(sv, *(_delim)); \
	assert(streq(_s, j)); \
	strings_free(sv); \
	free(s); \
	free(j); \
    } while (0);

/* Tests */

int test_00_string_chomp() {
    char   s1[]  = "later alligator\n";
    size_t size1 = strlen(s1);
    string_chomp(s1);
    assert(strlen(s1) == size1 - 1);
    assert(*(s1 + size1 - 1) == 0);
    
    char   s2[]  = "later alligator";
    size_t size2 = strlen(s1);
    string_chomp(s2);
    assert(strlen(s2) == size2);
    assert(*(s1 + size2) == 0);
    return EXIT_SUCCESS;
}

int test_01_string_split() {
    test_01_string_split_case(STRING0, " ");
    test_01_string_split_case(STRING1, " ");
    test_01_string_split_case(STRING2, " ");
    test_01_string_split_case(STRING3, ",");
    return EXIT_SUCCESS;
}

int test_02_strings_free() {
    test_02_strings_free_case(STRING0, " ");
    test_02_strings_free_case(STRING1, " ");
    test_02_strings_free_case(STRING2, " ");
    test_02_strings_free_case(STRING3, ",");
    return EXIT_SUCCESS;
}

int test_03_strings_size() {
    test_03_strings_size_case(STRING0, " ");
    test_03_strings_size_case(STRING1, " ");
    test_03_strings_size_case(STRING2, " ");
    test_03_strings_size_case(STRING3, ",");
    return EXIT_SUCCESS;
}

int test_04_strings_join() {
    test_04_strings_join_case(STRING0, " ");
    test_04_strings_join_case(STRING1, " ");
    test_04_strings_join_case(STRING2, " ");
    test_04_strings_join_case(STRING3, ",");
    return EXIT_SUCCESS;
}

/* Main Execution */

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s NUMBER\n\n", argv[0]);
        fprintf(stderr, "Where NUMBER is right of the following:\n");
        fprintf(stderr, "    0  Test string_chomp\n");
        fprintf(stderr, "    1  Test string_split\n");
        fprintf(stderr, "    2  Test strings_free\n");
        fprintf(stderr, "    3  Test strings_size\n");
        fprintf(stderr, "    4  Test strings_join\n");
        return EXIT_FAILURE;
    }   

    int number = atoi(argv[1]);
    int status = EXIT_FAILURE;

    switch (number) {
        case 0:  status = test_00_string_chomp(); break;
        case 1:  status = test_01_string_split(); break;
        case 2:  status = test_02_strings_free(); break;
        case 3:  status = test_03_strings_size(); break;
        case 4:  status = test_04_strings_join(); break;
        default: fprintf(stderr, "Unknown NUMBER: %d\n", number); break;
    }
    
    return status;
}

/* vim: set sts=4 sw=4 ts=8 expandtab ft=c: */
