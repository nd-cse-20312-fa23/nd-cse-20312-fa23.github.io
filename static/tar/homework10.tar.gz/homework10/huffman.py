#!/usr/bin/env python3

import sys

from node           import Node, walk
from priority_queue import PriorityQueue

# Functions

def count_frequencies(symbols: str) -> dict[str, int]:
    ''' Count the frequencies of each symbol in symbols.

    >>> count_frequencies('BACABA')
    {'B': 2, 'A': 3, 'C': 1}
    '''
    pass

def compute_compression_ratio(symbols: str, codes: dict[str, str]) -> float:
    ''' Compute the compression ratio of the symbols if the Huffman codes were
    to be used on the symbols.

    >>> ratio = compute_compression_ratio('BACABA', {'B': '11', 'A': '0', 'C': '10'})
    >>> print(f'{ratio:.2f}')
    5.33
    '''
    pass

# Main Execution

def main(stream=sys.stdin) -> None:
    ''' Compute the Huffman Code for all the symbols in the input stream.

    >>> import io
    >>> main(io.StringIO('BACABA'))
    A 0
    C 10
    B 11
    Ratio: 5.33
    '''
    # TODO: Count frequencies of each symbol
    pass

    # TODO: Construct priority queue of Nodes
    pass

    # TODO: Build Huffman tree
    pass

    # TODO: Walk Huffman tree to produce codes
    pass

    # TODO: Display Huffman codes
    pass

    # TODO: Display Compression ratio
    pass

if __name__ == '__main__':
    main()
