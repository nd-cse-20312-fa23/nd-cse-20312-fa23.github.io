#!/usr/bin/env python3

import sys

from priority_queue import PriorityQueue

# Functions

def fill_cups(cups):
    ''' Return minimum number of seconds required to fill all cups of water.

    Use a greedy algorithm by attempting to fill two types of cups at a time
    until there is only one remaining type.

    >>> fill_cups([1, 4, 2])
    4

    >>> fill_cups([5, 4, 4])
    7

    >>> fill_cups([5, 0, 0])
    5
    '''
    # TODO
    pass

# Main Execution

def main(stream=sys.stdin):
    ''' For each line of cups, determine the minimum number of seconds required
    to fill all cups of water.

    >>> import io
    >>> main(io.StringIO('1 4 2\\n5 4 4\\n5 0 0\\n'))
    4
    7
    5
    '''
    # TODO
    pass

if __name__ == '__main__':
    main()

# vim: set sts=4 sw=4 ts=8 expandtab ft=python:
