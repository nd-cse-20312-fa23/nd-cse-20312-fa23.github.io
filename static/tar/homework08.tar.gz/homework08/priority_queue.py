#!/usr/bin/env python3

# Class

class PriorityQueue:
    ''' Priority Queue

    Stores values in ascending order.
    '''

    def __init__(self, data=None):
        ''' Construct PriorityQueue with initial data.

        >>> p = PriorityQueue()
        >>> p.data
        []

        >>> p = PriorityQueue([5, 7, 4])
        >>> p.data
        [4, 5, 7]
        '''
        # TODO
        pass

    def push(self, value):
        ''' Add value to PriorityQueue.

        >>> p = PriorityQueue()
        >>> for i in (5, 7, 4): p.push(i)
        >>> p.data
        [4, 5, 7]
        '''
        # TODO
        pass

    def pop(self):
        ''' Remove largest value from PriorityQueue.

        >>> p = PriorityQueue([5, 7, 4])
        >>> [p.pop(), p.pop(), p.pop()]
        [7, 5, 4]
        '''
        # TODO
        pass

    @property
    def front(self):
        ''' Return largest value from PriorityQueue.

        >>> p = PriorityQueue([5, 7, 4])
        >>> p.front
        7
        '''
        # TODO
        pass

    @property
    def empty(self):
        ''' Return whether or not the PriorityQueue has any values.

        >>> PriorityQueue().empty
        True

        >>> PriorityQueue([5, 7, 4]).empty
        False
        '''
        # TODO
        pass

    def __len__(self):
        ''' Return number of values in PriorityQueue.

        >>> len(PriorityQueue())
        0

        >>> len(PriorityQueue([5, 7, 4]))
        3
        '''
        # TODO
        pass

# vim: set sts=4 sw=4 ts=8 expandtab ft=python:
