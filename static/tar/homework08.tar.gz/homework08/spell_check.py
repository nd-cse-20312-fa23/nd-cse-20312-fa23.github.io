#!/usr/bin/env python3

import collections
import sys

# Constants

WORDS_PATH = '/usr/share/dict/words'

# Classes

class WordsDatabase:
    ''' Words DataBase.

    Supports the "in" operation.
    '''

    def __contains__(self, target):
        ''' Returns whether or not target is in the database. '''
        # TODO
        pass

class WordsList(WordsDatabase):
    ''' Words Database that uses a list internally. '''

    def __init__(self, path=WORDS_PATH):
        ''' Construct Words Database by loading all words in path into internal
        list.

        >>> words = WordsList()
        >>> len(words.data) >= 100000
        True

        >>> 'the' in words
        True

        >>> 'thurr' in words
        False
        '''
        # TODO
        pass

class WordsSet(WordsDatabase):
    ''' Words Database that uses a set internally. '''

    def __init__(self, path=WORDS_PATH):
        ''' Construct Words Database by loading all words in path into internal
        set.

        >>> words = WordsList()
        >>> len(words.data) >= 100000
        True

        >>> 'the' in words
        True

        >>> 'thurr' in words
        False
        '''
        # TODO
        pass

class WordsDict(WordsDatabase):
    ''' Words Database that uses a dict internally. '''

    def __init__(self, path=WORDS_PATH):
        ''' Construct Words Database by loading all words in path into internal
        dict.

        >>> words = WordsList()
        >>> len(words.data) >= 100000
        True

        >>> 'the' in words
        True

        >>> 'thurr' in words
        False
        '''
        # TODO
        pass

# Constants

WORDS_DATABASES = {
    '-d': WordsDict,
    '-l': WordsList,
    '-s': WordsSet,
}

# Main Execution

def main(arguments=sys.argv[1:], stream=sys.stdin):
    ''' Perform a spell check on each word in the stream:

    1. Load appropriate Words Database.
    2. Read each line from stream.
    3. Check each word from each line.
    4. Print any words that are not in the Words Database.

    >>> import io
    >>> main(['-d'], io.StringIO('the thurr\\nshe shurr\\n'))
    thurr
    shurr

    >>> main(['-l'], io.StringIO('the thurr\\nshe shurr\\n'))
    thurr
    shurr

    >>> main(['-s'], io.StringIO('the thurr\\nshe shurr\\n'))
    thurr
    shurr
    '''
    # TODO
    pass

if __name__ == '__main__':
    main()

# vim: set sts=4 sw=4 ts=8 expandtab ft=python:
