#!/usr/bin/env python3

import sys

from typing import Iterator, Optional
from tree   import Node, tree_read

# Functions

def tree_paths(root: Optional[Node], path: list[int]=[]) -> Iterator[list[int]]:
    ''' Generate all the root to leaf paths in the tree.

    >>> for path in tree_paths(tree_read([1, 2, 3, 4])): print(path)
    [1, 2, 4]
    [1, 3]
    '''
    pass

# Main Execution

def main(stream=sys.stdin) -> None:
    ''' For each line, read in the tree in BFS format, and then print out all the paths in the tree.

    >>> import io
    >>> main(io.StringIO('1 2 3 4\\n'))
    1, 2, 4
    1, 3
    '''
    pass

if __name__ == '__main__':
    main()

# vim: set sts=4 sw=4 ts=8 expandtab ft=python:
