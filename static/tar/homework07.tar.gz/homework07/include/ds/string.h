/* string.h: String Functions */

#pragma once

/* Functions */

char *	    str_lower(char *);
char *	    str_trim(char *);

/* vim: set sts=4 sw=4 ts=8 expandtab ft=c: */
