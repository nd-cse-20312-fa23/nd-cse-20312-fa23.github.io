/* hash.h: Hash Functions */

#pragma once

#include <stdint.h>
#include <stdlib.h>

/* Type Definitions */

typedef uint64_t (*HashFunction)(const void *data, size_t n);

/* Functions */

uint64_t    djb_hash(const void *data, size_t n);
uint64_t    fnv_hash(const void *data, size_t n);

/* vim: set sts=4 sw=4 ts=8 expandtab ft=c: */
