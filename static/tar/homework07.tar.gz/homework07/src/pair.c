/* pair.c: Key/Value Pair Structure */

#include "ds/pair.h"

#include <stdlib.h>
#include <string.h>

/**
 * Allocate and initialize new Pair structure.
 *
 * @param   key             Pair's key.
 * @param   value           Pair's value.
 * @return  New Pair structure (must be deleted later).
 **/
Pair *	    pair_create(const char *key, int64_t value) {
    // TODO
    return NULL;
}

/**
 * Delete Pair structure.
 *
 * @param   p               Pointer to Pair structure.
 **/
void        pair_delete(Pair *p) {
    // TODO
}

/**
 * Format Pair by writing to stream.
 *
 * @param   p               Pointer to Pair structure.
 * @param   stream          File stream to write to.
 **/
void        pair_format(Pair *p, FILE *stream) {
    // TODO
}

/* vim: set sts=4 sw=4 ts=8 expandtab ft=c: */
