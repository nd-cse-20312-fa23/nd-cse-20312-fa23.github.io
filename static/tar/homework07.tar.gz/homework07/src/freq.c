/* freq.c: Word Frequency Utility */

#include "ds/table.h"
#include "ds/string.h"

#include <ctype.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Constants */

#define WHITESPACE  " \t\r\n"

/* Functions */

void	usage(int status) {
    fprintf(stderr, "Usage: freq [-a ALPHA -d -f]\n\n");
    fprintf(stderr, "Options:\n");
    fprintf(stderr, "    -a ALPHA   Set maximum load factor\n");
    fprintf(stderr, "    -d         Use DJB hash function\n");
    fprintf(stderr, "    -f         Use FNV hash function\n");
    fprintf(stderr, "\nBy default freq use 0.5 for ALPHA and FNV as its hash function.\n");
    exit(status);
}

/* Main Execution */

int	main(int argc, char *argv[]) {
    // TODO: Parse command-line options

    // TODO: Read input, add words to table, dump
    return EXIT_SUCCESS;
}
