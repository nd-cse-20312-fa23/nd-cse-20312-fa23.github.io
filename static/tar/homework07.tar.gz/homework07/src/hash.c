/* hash.c: Hash Functions */

#include "ds/hash.h"

/**
 * Constants
 * http://isthe.com/chongo/tech/comp/fnv/
 **/

#define DJB_OFFSET_BASIS    (5381L)
#define FNV_OFFSET_BASIS    (0xcbf29ce484222325ULL)
#define FNV_PRIME           (0x100000001b3ULL)

/**
 * Compute DJB hash.
 * @param   data            Data to hash.
 * @param   n               Number of bytes in data.
 * @return  Computed hash as 64-bit unsigned integer.
 **/
uint64_t    djb_hash(const void *data, size_t n) {
    // TODO
    return 0;
}

/**
 * Compute FNV-1a hash.
 * @param   data            Data to hash.
 * @param   n               Number of bytes in data.
 * @return  Computed FNV-1a hash as 64-bit unsigned integer.
 **/
uint64_t    fnv_hash(const void *data, size_t n) {
    // TODO
    return 0;
}

/* vim: set sts=4 sw=4 ts=8 expandtab ft=c: */
