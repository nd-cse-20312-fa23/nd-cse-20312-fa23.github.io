/* string.c: String Functions */

#include "ds/string.h"

#include <ctype.h>
#include <string.h>

/**
 * Convert all the characters in the string to lowercase.
 *
 * @param   s       String to convert.
 * @return  Pointer to the first character in string.
 **/
char *	str_lower(char *s) {
    // TODO
    return s;
}

/**
 * Trim front and back of string of any non-alphanumeric characters.
 *
 * @param   s       String to convert.
 * @return  Pointer to the first alphanumeric character in string.
 **/
char *	str_trim(char *s) {
    // TODO
    return s;
}

/* vim: set sts=4 sw=4 ts=8 expandtab ft=c: */
