/* unit_listset.c: Set (Linked List) Unit Test */

#include "ds/listset.h"

#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Constants */

const int64_t NUMBERS[] = {5, 4, 7, 0, 1, 4, 6, 6, 3, 7, -1};

/* Tests */

int test_00_listset_create() {
    ListSet *ls = listset_create(0, NULL);
    assert(ls);
    assert(ls->data == 0);
    assert(ls->next == NULL);
    free(ls);
    return EXIT_SUCCESS;
}

int test_01_listset_delete() {
    ListSet *ls = listset_create(0, NULL);
    assert(ls);
    assert(ls->data == 0);
    assert(ls->next == NULL);

    ls->next = listset_create(1, 
               listset_create(3,
               listset_create(4,
               listset_create(10, NULL))));

    listset_delete(ls);
    return EXIT_SUCCESS;
}

int test_02_listset_size() {
    ListSet *ls = listset_create(0, NULL);
    assert(ls);
    assert(ls->data == 0);
    assert(ls->next == NULL);
    assert(listset_size(ls) == 0);

    ls->next = listset_create(1, 
               listset_create(3,
               listset_create(4,
               listset_create(10, NULL))));
    assert(listset_size(ls) == 4);

    listset_delete(ls);
    return EXIT_SUCCESS;
}

int test_03_listset_contains() {
    ListSet *ls = listset_create(0, NULL);
    assert(ls);
    assert(ls->data == 0);
    assert(ls->next == NULL);
    assert(listset_size(ls) == 0);

    ls->next = listset_create(1, 
               listset_create(3,
               listset_create(4,
               listset_create(10, NULL))));
    assert(listset_size(ls) == 4);

    assert(listset_contains(ls, 1));
    assert(listset_contains(ls, 3));
    assert(listset_contains(ls, 4));
    assert(listset_contains(ls, 10));
    assert(!listset_contains(ls, 0));
    assert(!listset_contains(ls, 11));
    assert(!listset_contains(ls, 2));
    assert(!listset_contains(ls, 5));

    listset_delete(ls);
    return EXIT_SUCCESS;
}

int test_04_listset_add() {
    ListSet *ls = listset_create(0, NULL);
    assert(ls);
    assert(ls->data == 0);
    assert(ls->next == NULL);
    assert(listset_size(ls) == 0);

    for (const int64_t *n = NUMBERS; *n >= 0; n++) {
        listset_add(ls, *n);
    }
    assert(listset_size(ls) == 7);

    ListSet *prev  = ls;
    for (ListSet *curr = ls->next; curr; curr = curr->next) {
        assert(prev->data <= curr->data);
    }

    for (const int64_t *n = NUMBERS; *n >= 0; n++) {
        assert(listset_contains(ls, *n));
    }

    assert(!listset_contains(ls, 2));
    assert(!listset_contains(ls, 8));
    assert(!listset_contains(ls, 10));

    listset_delete(ls);
    return EXIT_SUCCESS;
}

int test_05_listset_remove() {
    ListSet *ls = listset_create(0, NULL);
    assert(ls);
    assert(ls->data == 0);
    assert(ls->next == NULL);
    assert(listset_size(ls) == 0);

    for (const int64_t *n = NUMBERS; *n >= 0; n++) {
        listset_add(ls, *n);
    }
    assert(listset_size(ls) == 7);

    ListSet *prev  = ls;
    for (ListSet *curr = ls->next; curr; curr = curr->next) {
        assert(prev->data <= curr->data);
    }

    for (const int64_t *n = NUMBERS; *n >= 0; n++) {
        assert(listset_contains(ls, *n));
    }

    assert(!listset_contains(ls, 2));
    assert(!listset_contains(ls, 8));
    assert(!listset_contains(ls, 10));
    
    for (const int64_t *n = NUMBERS; *n >= 0; n++) {
        listset_remove(ls, *n);
        assert(!listset_contains(ls, *n));
    }
    assert(listset_size(ls) == 0);
    assert(ls->next == NULL);
    listset_delete(ls);
    return EXIT_SUCCESS;
}

/* Main Execution */

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s NUMBER\n\n", argv[0]);
        fprintf(stderr, "Where NUMBER is right of the following:\n");
        fprintf(stderr, "    0  Test listset_create\n");
        fprintf(stderr, "    1  Test listset_delete\n");
        fprintf(stderr, "    2  Test listset_size\n");
        fprintf(stderr, "    3  Test listset_contains\n");
        fprintf(stderr, "    4  Test listset_add\n");
        fprintf(stderr, "    5  Test listset_remove\n");
        return EXIT_FAILURE;
    }

    int number = atoi(argv[1]);
    int status = EXIT_FAILURE;

    switch (number) {
        case 0:  status = test_00_listset_create(); break;
        case 1:  status = test_01_listset_delete(); break;
        case 2:  status = test_02_listset_size(); break;
        case 3:  status = test_03_listset_contains(); break;
        case 4:  status = test_04_listset_add(); break;
        case 5:  status = test_05_listset_remove(); break;
        default: fprintf(stderr, "Unknown NUMBER: %d\n", number); break;
    }

    return status;
}

/* vim: set sts=4 sw=4 ts=8 expandtab ft=c: */
