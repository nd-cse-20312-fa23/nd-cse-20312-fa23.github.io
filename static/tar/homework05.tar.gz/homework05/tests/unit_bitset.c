/* unit_bitset.c: Set (BitSet) Unit Test */

#include "ds/bitset.h"

#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Constants */

const int64_t NUMBERS[] = {5, 4, 7, 0, 1, 4, 6, 6, 3, 7, -1};

/* Tests */

int test_00_bitset_contains() {
    BitSet bs = (1<<1) | (1<<3) | (1<<4) | (1<<10);

    assert(bitset_contains(&bs, 1));
    assert(bitset_contains(&bs, 3));
    assert(bitset_contains(&bs, 4));
    assert(bitset_contains(&bs, 10));
    assert(!bitset_contains(&bs, 0));
    assert(!bitset_contains(&bs, 11));
    assert(!bitset_contains(&bs, 2));
    assert(!bitset_contains(&bs, 5));

    return EXIT_SUCCESS;
}

int test_01_bitset_add() {
    BitSet bs = 0;

    for (const int64_t *n = NUMBERS; *n >= 0; n++) {
        bitset_add(&bs, *n);
    }

    assert(bs == 251);

    for (const int64_t *n = NUMBERS; *n >= 0; n++) {
        assert(bitset_contains(&bs, *n));
    }

    assert(!bitset_contains(&bs, 2));
    assert(!bitset_contains(&bs, 8));
    assert(!bitset_contains(&bs, 10));

    return EXIT_SUCCESS;
}

int test_02_bitset_remove() {
    BitSet bs = 0;

    for (const int64_t *n = NUMBERS; *n >= 0; n++) {
        bitset_add(&bs, *n);
    }

    assert(bs == 251);

    for (const int64_t *n = NUMBERS; *n >= 0; n++) {
        assert(bitset_contains(&bs, *n));
    }

    assert(!bitset_contains(&bs, 2));
    assert(!bitset_contains(&bs, 8));
    assert(!bitset_contains(&bs, 10));

    for (const int64_t *n = NUMBERS; *n >= 0; n++) {
        bitset_remove(&bs, *n);
        assert(!bitset_contains(&bs, *n));
    }

    assert(bs == 0);

    return EXIT_SUCCESS;
}

int test_03_bitset_size() {
    BitSet bs = 0;

    for (const int64_t *n = NUMBERS; *n >= 0; n++) {
        bitset_add(&bs, *n);
    }

    assert(bs == 251);
    printf("%ld\n", bitset_size(&bs));
    assert(bitset_size(&bs) == 7);

    for (const int64_t *n = NUMBERS; *n >= 0; n++) {
        assert(bitset_contains(&bs, *n));
    }

    assert(!bitset_contains(&bs, 2));
    assert(!bitset_contains(&bs, 8));
    assert(!bitset_contains(&bs, 10));

    for (const int64_t *n = NUMBERS; *n >= 0; n++) {
        bitset_remove(&bs, *n);
        assert(!bitset_contains(&bs, *n));
    }

    assert(bs == 0);
    assert(bitset_size(&bs) == 0);
    return EXIT_SUCCESS;
}

/* Main Execution */

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s NUMBER\n\n", argv[0]);
        fprintf(stderr, "Where NUMBER is right of the following:\n");
        fprintf(stderr, "    0  Test bitset_contains\n");
        fprintf(stderr, "    1  Test bitset_add\n");
        fprintf(stderr, "    2  Test bitset_remove\n");
        fprintf(stderr, "    3  Test bitset_size\n");
        return EXIT_FAILURE;
    }

    int number = atoi(argv[1]);
    int status = EXIT_FAILURE;

    switch (number) {
        case 0:  status = test_00_bitset_contains(); break;
        case 1:  status = test_01_bitset_add(); break;
        case 2:  status = test_02_bitset_remove(); break;
        case 3:  status = test_03_bitset_size(); break;
        default: fprintf(stderr, "Unknown NUMBER: %d\n", number); break;
    }

    return status;
}

/* vim: set sts=4 sw=4 ts=8 expandtab ft=c: */
