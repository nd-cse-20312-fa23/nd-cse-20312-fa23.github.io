/* unit_arrayset.c: Set (Dynamic Array) Unit Test */

#include "ds/arrayset.h"

#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Constants */

const int64_t NUMBERS[] = {5, 4, 7, 0, 1, 4, 6, 6, 3, 7, -1};

/* Tests */

int test_00_arrayset_create() {
    ArraySet *as = arrayset_create();
    assert(as);
    assert(as->data);
    assert(as->capacity == ARRAYSET_DEFAULT_CAPACITY);
    assert(as->size     == 0);
    free(as->data);
    free(as);
    return EXIT_SUCCESS;
}

int test_01_arrayset_delete() {
    ArraySet *as = arrayset_create();
    assert(as);
    assert(as->data);
    assert(as->capacity == ARRAYSET_DEFAULT_CAPACITY);
    assert(as->size     == 0);
    arrayset_delete(as);
    return EXIT_SUCCESS;
}

int test_02_arrayset_contains() {
    ArraySet *as = arrayset_create();
    assert(as);
    assert(as->data);
    assert(as->capacity == ARRAYSET_DEFAULT_CAPACITY);
    assert(as->size     == 0);

    as->data[0] = 1;
    as->data[1] = 3;
    as->data[2] = 4;
    as->data[3] = 10;
    as->size    = 4;

    assert(arrayset_contains(as, 1));
    assert(arrayset_contains(as, 3));
    assert(arrayset_contains(as, 4));
    assert(arrayset_contains(as, 10));
    assert(!arrayset_contains(as, 0));
    assert(!arrayset_contains(as, 11));
    assert(!arrayset_contains(as, 2));
    assert(!arrayset_contains(as, 5));

    arrayset_delete(as);
    return EXIT_SUCCESS;
}

int test_03_arrayset_add() {
    ArraySet *as = arrayset_create();
    assert(as);
    assert(as->data);
    assert(as->capacity == ARRAYSET_DEFAULT_CAPACITY);
    assert(as->size     == 0);

    for (const int64_t *n = NUMBERS; *n >= 0; n++) {
        arrayset_add(as, *n);
    }

    assert(as->capacity == ARRAYSET_DEFAULT_CAPACITY*2);
    assert(as->size     == 7);

    for (const int64_t *n = NUMBERS; *n >= 0; n++) {
        assert(arrayset_contains(as, *n));
    }

    assert(!arrayset_contains(as, 2));
    assert(!arrayset_contains(as, 8));
    assert(!arrayset_contains(as, 10));

    arrayset_delete(as);
    return EXIT_SUCCESS;
}

int test_04_arrayset_remove() {
    ArraySet *as = arrayset_create();
    assert(as);
    assert(as->data);
    assert(as->capacity == ARRAYSET_DEFAULT_CAPACITY);
    assert(as->size     == 0);

    for (const int64_t *n = NUMBERS; *n >= 0; n++) {
        arrayset_add(as, *n);
    }

    assert(as->capacity == ARRAYSET_DEFAULT_CAPACITY*2);
    assert(as->size     == 7);

    for (const int64_t *n = NUMBERS; *n >= 0; n++) {
        assert(arrayset_contains(as, *n));
    }

    assert(!arrayset_contains(as, 2));
    assert(!arrayset_contains(as, 8));
    assert(!arrayset_contains(as, 10));

    for (const int64_t *n = NUMBERS; *n >= 0; n++) {
        arrayset_remove(as, *n);
        assert(!arrayset_contains(as, *n));
    }

    assert(as->size == 0);
    arrayset_delete(as);
    return EXIT_SUCCESS;
}

/* Main Execution */

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s NUMBER\n\n", argv[0]);
        fprintf(stderr, "Where NUMBER is right of the following:\n");
        fprintf(stderr, "    0  Test arrayset_create\n");
        fprintf(stderr, "    1  Test arrayset_delete\n");
        fprintf(stderr, "    2  Test arrayset_contains\n");
        fprintf(stderr, "    3  Test arrayset_add\n");
        fprintf(stderr, "    4  Test arrayset_remove\n");
        return EXIT_FAILURE;
    }

    int number = atoi(argv[1]);
    int status = EXIT_FAILURE;

    switch (number) {
        case 0:  status = test_00_arrayset_create(); break;
        case 1:  status = test_01_arrayset_delete(); break;
        case 2:  status = test_02_arrayset_contains(); break;
        case 3:  status = test_03_arrayset_add(); break;
        case 4:  status = test_04_arrayset_remove(); break;
        default: fprintf(stderr, "Unknown NUMBER: %d\n", number); break;
    }

    return status;
}

/* vim: set sts=4 sw=4 ts=8 expandtab ft=c: */
