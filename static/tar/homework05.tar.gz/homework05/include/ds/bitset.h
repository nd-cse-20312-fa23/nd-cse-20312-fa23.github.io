/* bitset.h: Set (BitSet) */

#pragma once

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

/* Type Definitions */

typedef uint64_t BitSet;

/* Functions */

bool	    bitset_contains(BitSet *bs, int64_t value);
void	    bitset_add(BitSet *bs, int64_t value);
void	    bitset_remove(BitSet *bs, int64_t value);
size_t	    bitset_size(BitSet *bs);
