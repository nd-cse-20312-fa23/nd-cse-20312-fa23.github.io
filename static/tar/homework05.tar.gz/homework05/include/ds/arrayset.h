/* arrayset.h: Set (Dynamic Array) */

#pragma once

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

/* Constants */

#define ARRAYSET_DEFAULT_CAPACITY (1<<2)

/* Structures */

typedef struct {
    int64_t *data;	// Internal array
    size_t   capacity;	// Total number of elements
    size_t   size;	// Number of valid elements
} ArraySet;

/* Functions */

ArraySet *  arrayset_create();
void	    arrayset_delete(ArraySet *as);

bool	    arrayset_contains(ArraySet *as, int64_t value);
void	    arrayset_add(ArraySet *as, int64_t value);
void	    arrayset_remove(ArraySet *as, int64_t value);

