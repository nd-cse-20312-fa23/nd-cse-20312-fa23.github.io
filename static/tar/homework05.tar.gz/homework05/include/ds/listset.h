/* listset.h: Set (Linked List) */

#pragma once

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

/* Structures */

typedef struct ListSet ListSet;
struct ListSet {
    int64_t  data;
    ListSet *next;
};

/* Functions */

ListSet *   listset_create(int64_t data, ListSet *next);
void	    listset_delete(ListSet *ls);

size_t	    listset_size(ListSet *ls);
bool	    listset_contains(ListSet *ls, int64_t value);
void	    listset_add(ListSet *ls, int64_t value);
void	    listset_remove(ListSet *ls, int64_t value);
