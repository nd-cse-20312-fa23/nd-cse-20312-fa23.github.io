/* bitset.c: Set (BitSet) */

#include "ds/bitset.h"

/* Functions */

/**
 * Determine if value is in the BitSet.
 *
 * @param   bs		BitSet
 * @param   value	Integer value to search for.
 * @return  true if value is in BitSet, otherwise false.
 **/
bool	    bitset_contains(BitSet *bs, int64_t value) {
    // TODO
    return false;
}

/**
 * Add value to the BitSet.
 *
 * @param   bs		BitSet
 * @param   value	Integer value to add.
 **/
void	    bitset_add(BitSet *bs, int64_t value) {
    // TODO
}

/**
 * Remove value from the BitSet.
 *
 * @param   bs		BitSet
 * @param   value	Integer value to remove.
 **/
void	    bitset_remove(BitSet *bs, int64_t value) {
    // TODO
}

/**
 * Determine how many values are in BitSet.
 *
 * @param   bs		BitSet
 * @return  Number of values in the BitSet.
 **/
size_t	    bitset_size(BitSet *bs) {
    // TODO
    return 0;
}
