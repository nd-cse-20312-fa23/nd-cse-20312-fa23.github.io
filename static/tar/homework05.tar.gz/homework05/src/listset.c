/* listset.c: Set (Linked List) */

#include "ds/listset.h"

/* Prototypes */

size_t	    listset_size_r(ListSet *curr);
bool	    listset_contains_r(ListSet *curr, int64_t value);
void	    listset_add_r(ListSet *prev, ListSet *curr, int64_t value);
void	    listset_remove_r(ListSet *prev, ListSet *curr, int64_t value);

/* Functions */

/**
 * Allocate and initialize a new ListSet structure.
 *
 * @param   data	Integer data.
 * @param   next	Pointer to next ListSet structure.
 * @return  New ListSet structure (must be deleted later).
 **/
ListSet *   listset_create(int64_t data, ListSet *next) {
    // TODO
    return NULL;
}

/**
 * Recursively release ListSet structure and the rest of the sequence.
 *
 * @param   ls		Pointer to ListSet structure.
 **/
void	    listset_delete(ListSet *ls) {
    // TODO
}

/**
 * Recursively determine the number of values in the ListSet structure.
 *
 * @param   ls		Pointer to ListSet structure.
 * @return  Number of values in ListSet structure.
 **/
size_t	    listset_size(ListSet *ls) {
    // TODO
    return 0;
}

/**
 * Recursively determine the number of values in the ListSet structure.
 *
 * @param   curr	Pointer to ListSet structure.
 * @return  Number of values in ListSet structure.
 **/
size_t	    listset_size_r(ListSet *curr) {
    // TODO
    return 0;
}

/**
 * Recursively determine if value is in the ListSet structure.
 *
 * @param   ls		Pointer to ListSet structure.
 * @param   value	Integer value to search for.
 * @return  true if value is in the ListSet structure, otherwise false.
 **/
bool	    listset_contains(ListSet *ls, int64_t value) {
    // TODO
    return false;
}

/**
 * Recursively determine if value is in the ListSet structure.
 *
 * @param   curr	Pointer to ListSet structure.
 * @param   value	Integer value to search for.
 * @return  true if value is in the ListSet structure, otherwise false.
 **/
bool	    listset_contains_r(ListSet *curr, int64_t value) {
    // TODO
    return false;
}

/**
 * Recursively add value into the ListSet structure.
 *
 * @param   ls		Pointer to ListSet structure.
 * @param   value	Integer value to add.
 **/
void	    listset_add(ListSet *ls, int64_t value) {
    // TODO
}

/**
 * Recursively add value into the ListSet structure.
 *
 * @param   prev	Pointer to previous ListSet structure.
 * @param   curr	Pointer to current ListSet structure.
 * @param   value	Integer value to add.
 **/
void	    listset_add_r(ListSet *prev, ListSet *curr, int64_t value) {
    // TODO
}

/**
 * Recursively remove value from the ListSet structure.
 *
 * @param   ls		Pointer to ListSet structure.
 * @param   value	Integer value to remove.
 **/
void	    listset_remove(ListSet *ls, int64_t value) {
    // TODO
}

/**
 * Recursively remove value from the ListSet structure.
 *
 * @param   prev	Pointer to previous ListSet structure.
 * @param   curr	Pointer to current ListSet structure.
 * @param   value	Integer value to remove.
 **/
void	    listset_remove_r(ListSet *prev, ListSet *curr, int64_t value) {
    // TODO
}
