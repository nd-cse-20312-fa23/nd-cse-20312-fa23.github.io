/* arrayset.c: Set (Dynamic Array) */

#include "ds/arrayset.h"

#include <string.h>

/* Functions */

/**
 * Allocate and initialize a new ArraySet structure.
 *
 * @return  New ArraySet structure (must be deleted later).
 */
ArraySet*   arrayset_create() {
    // TODO
    return NULL;
}

/**
 * Release internal data of ArraySet and the structure itself.
 *
 * @param   as	    Pointer to ArraySet.
 **/
void	    arrayset_delete(ArraySet *as) {
    // TODO
}

/**
 * Determine if value is in the ArraySet.
 *
 * @param   as	    Pointer to ArraySet.
 * @param   value   Integer value to search for.
 * @return  true if value is in ArraySet, otherwise false.
 **/
bool	    arrayset_contains(ArraySet *as, int64_t value) {
    // TODO
    return false;
}

/**
 * Add value to ArraySet.
 *
 *  Note: values must be unique and stored in ascending order.
 *
 * @param   as	    Pointer to ArraySet.
 * @param   value   Integer value to add.
 **/
void	    arrayset_add(ArraySet *as, int64_t value) {
    // TODO
}

/**
 * Remove value from ArraySet.
 *
 * @param   as	    Pointer to ArraySet.
 * @param   value   Integer value to remove.
 **/
void	    arrayset_remove(ArraySet *as, int64_t value) {
    // TODO
}
