/* palindromic.c: Determine if word is a palindromic permutation */

#include "ds/arrayset.h"
#include "ds/bitset.h"
#include "ds/listset.h"

#include <ctype.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Type Definition */

typedef bool (*Function)(const char *s);

/* Functions */

void	usage(int status) {
    fprintf(stderr, "Usage: palindromic [-a -l -b]\n");
    exit(status);
}

/**
 * Determine if word is a palindromic permutation using an ArraySet.
 *
 * @param   s	    String
 * @return  true if word is a palindromic permutation, otherwise false.
 **/
bool	is_palindromic_arrayset(const char *s) {
    // TODO
    return false;
}

/**
 * Determine if word is a palindromic permutation using a ListSet.
 *
 * @param   s	    String
 * @return  true if word is a palindromic permutation, otherwise false.
 **/
bool	is_palindromic_listset(const char *s) {
    // TODO
    return false;
}

/**
 * Determine if word is a palindromic permutation using a BitSet.
 *
 * @param   s	    String
 * @return  true if word is a palindromic permutation, otherwise false.
 **/
bool	is_palindromic_bitset(const char *s) {
    // TODO
    return false;
}

/* Main Execution */

int	main(int argc, char *argv[]) {
    if (argc != 2) {
    	usage(EXIT_FAILURE);
    }

    Function is_palindromic = NULL;
    if (strcmp(argv[1], "-a") == 0) {
    	is_palindromic = is_palindromic_arrayset;
    } else if (strcmp(argv[1], "-l") == 0) {
    	is_palindromic = is_palindromic_listset;
    } else if (strcmp(argv[1], "-b") == 0) {
    	is_palindromic = is_palindromic_bitset;
    } else {
    	usage(EXIT_FAILURE);
    }

    char buffer[BUFSIZ];
    while (fgets(buffer, BUFSIZ, stdin)) {
    	buffer[strlen(buffer) - 1] = 0;
    	puts(is_palindromic(buffer) ? "YEAH" : "NOPE");
    }

    return EXIT_SUCCESS;
}
