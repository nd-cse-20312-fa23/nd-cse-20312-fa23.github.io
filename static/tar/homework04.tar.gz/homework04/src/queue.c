/* queue.c: Queue Structure */

#include "ds/queue.h"

#include <stdlib.h>
#include <string.h>

/* Functions */

/**
 * Create a Queue structure.
 *
 * @param   capacity	Capacity (or limit) of the Queue.
 * @return  Pointer to new Queue structure (must be deleted later).
 **/
Queue *	queue_create(size_t capacity) {
    // TODO
    return NULL;
}

/**
 * Delete Queue structure.
 *
 * @param   q		Pointer to Queue structure.
 **/
void	queue_delete(Queue *q) {
    // TODO
}

/**
 * Add value to back of the Queue.
 *
 * @param   q		Pointer to Queue structure.
 * @param   s		String value to add to Queue.
 **/
void	queue_push(Queue *q, const char *s) {
    // TODO
}

/**
 * Remove and return value from front of the Queue.
 *
 * @param   q		Pointer to Queue structure.
 * @return  String value (must be freed).
 **/
char *	queue_pop(Queue *q) {
    // TODO
    return NULL;
}

/**
 * Return whether or not the Queue is empty (has any values).
 *
 * @param   q		Pointer to Queue structure.
 * @return  Whether or not the Queue is empty.
 **/
bool	queue_empty(Queue *q) {
    // TODO
    return false;
}

/**
 * Print values in Queue to specified stream.
 *
 * @param   q		Pointer to Queue structure.
 * @param   s		File stream.
 **/
void	queue_dump(Queue *q, FILE *s) {
    // TODO
}

/**
 * Reverse all values in Queue.
 *
 * @param   q		Pointer to Queue structure.
 **/
void	queue_reverse(Queue *q) {
    // TODO
}
