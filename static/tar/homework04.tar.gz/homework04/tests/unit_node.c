/* unit_node.c: Node Structure Unit Test */

#include "ds/node.h"

#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Constants */

/* Tests */

int test_00_node_create() {
    Node *n1 = node_create("sticks", NULL, NULL);
    assert(n1);
    assert(strcmp(n1->data, "sticks") == 0);
    assert(n1->next == NULL);
    assert(n1->prev == NULL);
    
    Node *n2 = node_create("and", n1, NULL);
    assert(n2);
    assert(strcmp(n2->data, "and") == 0);
    assert(n2->next == n1);
    assert(n2->prev == NULL);
    
    Node *n3 = node_create("stones", n1, n2);
    assert(n3);
    assert(strcmp(n3->data, "stones") == 0);
    assert(n3->next == n1);
    assert(n3->prev == n2);

    free(n1->data);
    free(n1);
    free(n2->data);
    free(n2);
    free(n3->data);
    free(n3);
    return EXIT_SUCCESS;
}

int test_01_node_delete() {
    Node *n1 = node_create("sticks", NULL, NULL);
    assert(n1);
    assert(strcmp(n1->data, "sticks") == 0);
    assert(n1->next == NULL);
    assert(n1->prev == NULL);
    
    Node *n2 = node_create("and", n1, NULL);
    assert(n2);
    assert(strcmp(n2->data, "and") == 0);
    assert(n2->next == n1);
    assert(n2->prev == NULL);
    
    Node *n3 = node_create("stones", n1, n2);
    assert(n3);
    assert(strcmp(n3->data, "stones") == 0);
    assert(n3->next == n1);
    assert(n3->prev == n2);

    node_delete(n1);
    node_delete(n2);
    node_delete(n3);
    return EXIT_SUCCESS;
}

/* Main Execution */

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s NUMBER\n\n", argv[0]);
        fprintf(stderr, "Where NUMBER is right of the following:\n");
        fprintf(stderr, "    0  Test node_create\n");
        fprintf(stderr, "    1  Test node_delete\n");
        return EXIT_FAILURE;
    }   

    int number = atoi(argv[1]);
    int status = EXIT_FAILURE;

    switch (number) {
        case 0:  status = test_00_node_create(); break;
        case 1:  status = test_01_node_delete(); break;
        default: fprintf(stderr, "Unknown NUMBER: %d\n", number); break;
    }
    
    return status;
}

/* vim: set sts=4 sw=4 ts=8 expandtab ft=c: */
