/* node.h: Node Structure */

#pragma once

#include <stdio.h>
#include <stdlib.h>

/* Structure */

typedef struct Node Node;
struct Node {
    char *data;
    Node *next;
};

/* Type Definitions */

typedef int (*Comparison)(const void *, const void *);

/* Functions */

Node *	node_create(char *data, Node *next);
void	node_delete(Node *n);

int	node_compare_as_strings(const void *a, const void *b);
int	node_compare_as_numbers(const void *a, const void *b);
