/* sorts.h: Sorting Algorithms */

#pragma once

#include "ds/list.h"

/* Functions */

void	selection_sort(List *l, Comparison cmp);
void	merge_sort(List *l, Comparison cmp);
void	quick_sort(List *l, Comparison cmp);
