/* list.h: List Structure */

#pragma once

#include "node.h"

#include <stdio.h>
#include <stdlib.h>

/* Structure */

typedef struct {
    Node  *head;
    Node  *tail;
    size_t size;
} List;

/* Functions */

List *	list_create();
void	list_delete(List *l);

void	list_append(List *l, char *s);
void	list_dump(List *l, FILE *fs);

void	list_split(Node *n, Node **left, Node **right);
Node *	list_merge(Node *left, Node *right, Comparison cmp);

Node**	list_nodes(List *l);
void	list_update(List *l, Node **a);
