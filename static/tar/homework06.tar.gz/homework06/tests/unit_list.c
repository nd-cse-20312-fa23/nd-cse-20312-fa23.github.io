/* unit_list.c: List Structure Unit Test */

#include "ds/list.h"

#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

/* Constants */

const char *STRINGS[] = {
    "And if it's over",
    "If you ever feel loved or needed",
    "Just be glad that you did and stay there",
    "Keep moving on",
    "Remember that you're one of the lucky ones",
    "It was bound to happen so just",
    "Just remember what I told you",
    "No perfect endings",
    "So if you made it",
    "There are no perfect endings",
};

const size_t STRINGS_SIZE = sizeof(STRINGS)/sizeof(char *);

/* Macros */

#define min(a, b)   (((a) < (b)) ? (a) : (b))

/* Tests */

int test_00_list_create() {
    List *l = list_create();
    assert(l);
    assert(l->head == NULL);
    assert(l->tail == NULL);
    assert(l->size == 0);

    free(l);
    return EXIT_SUCCESS;
}

int test_01_list_delete() {
    List *l = list_create();
    assert(l);
    assert(l->head == NULL);
    assert(l->tail == NULL);
    assert(l->size == 0);

    for (size_t i = 0; i < STRINGS_SIZE; i++) {
        l->head = node_create((char *)STRINGS[i], l->head);
    }

    list_delete(l);
    return EXIT_SUCCESS;
}

int test_02_list_append() {
    List *l = list_create();
    assert(l);
    assert(l->head == NULL);
    assert(l->tail == NULL);
    assert(l->size == 0);

    for (size_t i = 0; i < STRINGS_SIZE; i++) {
        list_append(l, (char *)STRINGS[i]);
    }

    Node *curr = l->head;
    for (size_t i = 0; i < STRINGS_SIZE; i++, curr = curr->next) {
        assert(strcmp(curr->data, STRINGS[i]) == 0);
    }

    list_delete(l);
    return EXIT_SUCCESS;
}

int test_03_list_dump() {
    List *l = list_create();
    assert(l);
    assert(l->head == NULL);
    assert(l->tail == NULL);
    assert(l->size == 0);

    for (size_t i = 0; i < STRINGS_SIZE; i++) {
        list_append(l, (char *)STRINGS[i]);
    }

    Node *curr = l->head;
    for (size_t i = 0; i < STRINGS_SIZE; i++, curr = curr->next) {
        assert(strcmp(curr->data, STRINGS[i]) == 0);
    }

    char tmp_path[BUFSIZ] = "/tmp/unit_list_XXXXXXX";
    int fd = mkstemp(tmp_path);
    if (fd < 0) {
        return EXIT_FAILURE;
    }
    FILE *fs = fdopen(fd, "r+");
    if (!fs) {
        return EXIT_FAILURE;
    }
    unlink(tmp_path);

    list_dump(l, fs);
    rewind(fs);

    char buffer[BUFSIZ];
    curr = l->head;
    while (fgets(buffer, BUFSIZ, fs) && curr) {
        buffer[strlen(buffer) - 1] = 0;
        assert(strcmp(curr->data, buffer) == 0);
        curr = curr->next;
    }

    list_delete(l);
    return EXIT_SUCCESS;
}

int test_04_list_split() {
    List *ll = list_create();
    assert(ll);
    assert(ll->head == NULL);
    assert(ll->tail == NULL);
    assert(ll->size == 0);

    for (size_t i = 0; i < STRINGS_SIZE; i++) {
        list_append(ll, (char *)STRINGS[i]);
    }

    Node *curr = ll->head;
    for (size_t i = 0; i < STRINGS_SIZE; i++, curr = curr->next) {
        assert(strcmp(curr->data, STRINGS[i]) == 0);
    }

    Node *left;
    Node *right;

    list_split(ll->head, &left, &right);
    assert(left);
    assert(strcmp(left->data, STRINGS[0]) == 0);
    assert(right);
    assert(strcmp(right->data, STRINGS[STRINGS_SIZE/2]) == 0);

    Node *tail = left;
    for (size_t i = 0; i < STRINGS_SIZE/2 && tail; i++) {
        tail = tail->next;
    }
    assert(tail == NULL);

    List *lr = list_create();
    lr->head = right;

    list_split(ll->head, &left, &right);
    assert(left);
    assert(strcmp(left->data, STRINGS[0]) == 0);
    assert(right);
    assert(strcmp(right->data, STRINGS[STRINGS_SIZE/4]) == 0);

    tail = left;
    for (size_t i = 0; i < STRINGS_SIZE/4 && tail; i++) {
        tail = tail->next;
    }
    assert(tail == NULL);

    List *llr = list_create();
    llr->head = right;

    list_delete(ll);
    list_delete(lr);
    list_delete(llr);
    return EXIT_SUCCESS;
}

int test_05_list_merge() {
    List *l = list_create();
    assert(l);
    assert(l->head == NULL);
    assert(l->tail == NULL);
    assert(l->size == 0);

    for (size_t i = 0; i < STRINGS_SIZE; i++) {
        list_append(l, (char *)STRINGS[i]);
    }

    Node *curr = l->head;
    for (size_t i = 0; i < STRINGS_SIZE; i++, curr = curr->next) {
        assert(strcmp(curr->data, STRINGS[i]) == 0);
    }

    Node *left;
    Node *right;

    list_split(l->head, &left, &right);
    assert(left);
    assert(strcmp(left->data, STRINGS[0]) == 0);
    assert(right);
    assert(strcmp(right->data, STRINGS[STRINGS_SIZE/2]) == 0);

    Node *tail = left;
    for (size_t i = 0; i < STRINGS_SIZE/2 && tail; i++) {
        tail = tail->next;
    }
    assert(tail == NULL);

    l->head = list_merge(left, right, node_compare_as_strings);
    for (curr = l->head; curr->next; curr = curr->next) {
        assert(strcmp(curr->data, curr->next->data) <= 0);
    }

    list_delete(l);
    return EXIT_SUCCESS;
}

int test_06_list_nodes() {
    List *l = list_create();
    assert(l);
    assert(l->head == NULL);
    assert(l->tail == NULL);
    assert(l->size == 0);

    for (size_t i = 0; i < STRINGS_SIZE; i++) {
        list_append(l, (char *)STRINGS[i]);
    }

    Node *curr = l->head;
    for (size_t i = 0; i < STRINGS_SIZE; i++, curr = curr->next) {
        assert(strcmp(curr->data, STRINGS[i]) == 0);
    }

    Node **nodes = list_nodes(l);
    curr = l->head;
    for (size_t i = 0; i < STRINGS_SIZE; i++, curr = curr->next) {
        assert(nodes[i] == curr);
    }

    free(nodes);
    list_delete(l);
    return EXIT_SUCCESS;
}

int test_07_list_update() {
    List *l = list_create();
    assert(l);
    assert(l->head == NULL);
    assert(l->tail == NULL);
    assert(l->size == 0);

    for (size_t i = 0; i < STRINGS_SIZE; i++) {
        list_append(l, (char *)STRINGS[i]);
    }

    Node *curr = l->head;
    for (size_t i = 0; i < STRINGS_SIZE; i++, curr = curr->next) {
        assert(strcmp(curr->data, STRINGS[i]) == 0);
    }

    Node **nodes = list_nodes(l);
    curr = l->head;
    for (size_t i = 0; i < STRINGS_SIZE; i++, curr = curr->next) {
        assert(nodes[i] == curr);
    }

    for (size_t i = 0; i < STRINGS_SIZE / 2; i++) {
        Node *tmp                   = nodes[i];
        nodes[i]                    = nodes[STRINGS_SIZE - i - 1];
        nodes[STRINGS_SIZE - i - 1] = tmp;
    }

    list_update(l, nodes);

    assert(l->head == nodes[0]);
    assert(l->tail == nodes[STRINGS_SIZE - 1]);
    assert(l->tail->next == NULL);

    curr = l->head;
    for (size_t i = 0; i < STRINGS_SIZE; i++, curr = curr->next) {
        assert(curr == nodes[i]);
    }

    free(nodes);
    list_delete(l);
    return EXIT_SUCCESS;
}

/* Main Execution */

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s NUMBER\n\n", argv[0]);
        fprintf(stderr, "Where NUMBER is right of the following:\n");
        fprintf(stderr, "    0  Test list_create\n");
        fprintf(stderr, "    1  Test list_delete\n");
        fprintf(stderr, "    2  Test list_append\n");
        fprintf(stderr, "    3  Test list_dump\n");
        fprintf(stderr, "    4  Test list_split\n");
        fprintf(stderr, "    5  Test list_merge\n");
        fprintf(stderr, "    6  Test list_nodes\n");
        fprintf(stderr, "    7  Test list_update\n");
        return EXIT_FAILURE;
    }

    int number = atoi(argv[1]);
    int status = EXIT_FAILURE;

    switch (number) {
        case 0:  status = test_00_list_create(); break;
        case 1:  status = test_01_list_delete(); break;
        case 2:  status = test_02_list_append(); break;
        case 3:  status = test_03_list_dump(); break;
        case 4:  status = test_04_list_split(); break;
        case 5:  status = test_05_list_merge(); break;
        case 6:  status = test_06_list_nodes(); break;
        case 7:  status = test_07_list_update(); break;
        default: fprintf(stderr, "Unknown NUMBER: %d\n", number); break;
    }

    return status;
}

/* vim: set sts=4 sw=4 ts=8 expandtab ft=c: */
