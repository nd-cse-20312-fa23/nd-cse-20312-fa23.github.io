/* unit_selection.c: Selection Sort Unit Test */

#include "ds/sorts.h"

#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Constants */

const char *STRINGS[] = {
    "So if you made it",
    "Just be glad that you did and stay there",
    "If you ever feel loved or needed",
    "Remember that you're one of the lucky ones",
    "And if it's over",
    "Just remember what I told you",
    "It was bound to happen so just",
    "Keep moving on",
    "There are no perfect endings",
    "No perfect endings",
};

const char *NUMBERS[] = {
    "5", "4", "7", "0", "1", "4", "6", "6", "3", "7",
};

/* Tests */

int test_00_selection_sort_strings() {
    List *l = list_create();
    assert(l);
    assert(l->head == NULL);
    assert(l->tail == NULL);
    assert(l->size == 0);

    for (size_t i = 0; i < sizeof(STRINGS)/sizeof(char *); i++) {
        list_append(l, (char *)STRINGS[i]);
    }

    selection_sort(l, node_compare_as_strings);

    for (Node *curr = l->head; curr->next; curr = curr->next) {
        assert(strcmp(curr->data, curr->next->data) <= 0);
    }

    assert(strcmp(l->head->data, STRINGS[4]) == 0);
    assert(strcmp(l->tail->data, STRINGS[8]) == 0);

    list_delete(l);
    return EXIT_SUCCESS;
}

int test_01_selection_sort_numbers() {
    List *l = list_create();
    assert(l);
    assert(l->head == NULL);
    assert(l->tail == NULL);
    assert(l->size == 0);

    for (size_t i = 0; i < sizeof(NUMBERS)/sizeof(char *); i++) {
        list_append(l, (char *)NUMBERS[i]);
    }

    selection_sort(l, node_compare_as_numbers);

    for (Node *curr = l->head; curr->next; curr = curr->next) {
        assert(atoi(curr->data) <= atoi(curr->next->data));
    }

    assert(atoi(l->head->data) == 0);
    assert(atoi(l->tail->data) == 7);

    list_delete(l);
    return EXIT_SUCCESS;
}

/* Main Execution */

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s NUMBER\n\n", argv[0]);
        fprintf(stderr, "Where NUMBER is right of the following:\n");
        fprintf(stderr, "    0  Test selection_sort_strings\n");
        fprintf(stderr, "    1  Test selection_sort_numbers\n");
        return EXIT_FAILURE;
    }

    int number = atoi(argv[1]);
    int status = EXIT_FAILURE;

    switch (number) {
        case 0:  status = test_00_selection_sort_strings(); break;
        case 1:  status = test_01_selection_sort_numbers(); break;
        default: fprintf(stderr, "Unknown NUMBER: %d\n", number); break;
    }

    return status;
}

/* vim: set sts=4 sw=4 ts=8 expandtab ft=c: */
