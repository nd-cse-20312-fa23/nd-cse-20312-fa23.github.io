/* unit_node.c: Node Structure Unit Test */

#include "ds/node.h"

#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Constants */

/* Tests */

int test_00_node_create() {
    Node *n1 = node_create("perfect", NULL);
    assert(n1);
    assert(strcmp(n1->data, "perfect") == 0);
    assert(n1->next == NULL);

    Node *n2 = node_create("endings", n1);
    assert(n2);
    assert(strcmp(n2->data, "endings") == 0);
    assert(n2->next == n1);

    free(n1->data);
    free(n1);
    free(n2->data);
    free(n2);
    return EXIT_SUCCESS;
}

int test_01_node_delete() {
    Node *n1 = node_create("perfect", NULL);
    assert(n1);
    assert(strcmp(n1->data, "perfect") == 0);
    assert(n1->next == NULL);

    Node *n2 = node_create("endings", n1);
    assert(n2);
    assert(strcmp(n2->data, "endings") == 0);
    assert(n2->next == n1);

    node_delete(n1);
    node_delete(n2);
    return EXIT_SUCCESS;
}

int test_02_node_compare_as_strings() {
    Node *n1 = node_create("perfect", NULL);
    assert(n1);
    assert(strcmp(n1->data, "perfect") == 0);
    assert(n1->next == NULL);

    Node *n2 = node_create("endings", n1);
    assert(n2);
    assert(strcmp(n2->data, "endings") == 0);
    assert(n2->next == n1);

    assert(node_compare_as_strings(&n1, &n1) == 0);
    assert(node_compare_as_strings(&n1, &n2) > 0);
    assert(node_compare_as_strings(&n2, &n1) < 0);

    node_delete(n1);
    node_delete(n2);
    return EXIT_SUCCESS;
}

int test_03_node_compare_as_numbers() {
    Node *n1 = node_create("42", NULL);
    assert(n1);
    assert(strcmp(n1->data, "42") == 0);
    assert(n1->next == NULL);

    Node *n2 = node_create("24", n1);
    assert(n2);
    assert(strcmp(n2->data, "24") == 0);
    assert(n2->next == n1);

    assert(node_compare_as_numbers(&n1, &n1) == 0);
    assert(node_compare_as_numbers(&n1, &n2) > 0);
    assert(node_compare_as_numbers(&n2, &n1) < 0);

    node_delete(n1);
    node_delete(n2);
    return EXIT_SUCCESS;
}

/* Main Execution */

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s NUMBER\n\n", argv[0]);
        fprintf(stderr, "Where NUMBER is right of the following:\n");
        fprintf(stderr, "    0  Test node_create\n");
        fprintf(stderr, "    1  Test node_delete\n");
        fprintf(stderr, "    2  Test node_compare_as_strings\n");
        fprintf(stderr, "    3  Test node_compare_as_numbers\n");
        return EXIT_FAILURE;
    }

    int number = atoi(argv[1]);
    int status = EXIT_FAILURE;

    switch (number) {
        case 0:  status = test_00_node_create(); break;
        case 1:  status = test_01_node_delete(); break;
        case 2:  status = test_02_node_compare_as_strings(); break;
        case 3:  status = test_03_node_compare_as_numbers(); break;
        default: fprintf(stderr, "Unknown NUMBER: %d\n", number); break;
    }

    return status;
}

/* vim: set sts=4 sw=4 ts=8 expandtab ft=c: */
