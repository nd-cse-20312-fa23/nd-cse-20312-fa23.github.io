/* quick_sort.c: Quick Sort */

#include "ds/sorts.h"

/* Functions */

/**
 * Perform quick sort on the given List and order values using the
 * specified Comparison function.
 *
 * @param	l	Pointer to List structure.
 * @param	cmp	Pointer to Comparison function.
 **/
void	quick_sort(List *l, Comparison cmp) {
    // TODO
}
