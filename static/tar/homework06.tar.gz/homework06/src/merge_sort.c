/* merge_sort.c: Merge Sort */

#include "ds/sorts.h"

/* Prototypes */

Node *	merge_sort_r(Node *n, Comparison cmp);

/* Functions */

/** 
 * Perform merge sort on the given List and order values using the
 * specified Comparison function.
 *
 * @param       l       Pointer to List structure.
 * @param       cmp     Pointer to Comparison function.
 **/
void	merge_sort(List *l, Comparison cmp) {
    // TODO
}

/**
 * Use divide-and-conquer to recursively perform merge sort on the given List
 * and order values using the specified Comparison function.
 *
 * @param       n       Pointer to Node structure.
 * @param       cmp     Pointer to Comparison function.
 * @return  Pointer to the first Node structure in sorted sequence.
 **/
Node *	merge_sort_r(Node *n, Comparison cmp) {
    // TODO
    return NULL;
}
