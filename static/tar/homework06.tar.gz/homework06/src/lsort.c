/* lsort.c: List Sort Utility */

#include "ds/sorts.h"

#include <ctype.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Type Definition */

typedef void (*Function)(List *l, Comparison cmp);

/* Functions */

void	usage(int status) {
    fprintf(stderr, "Usage: lsort [-m -q -n]\n\n");
    fprintf(stderr, "Options:\n");
    fprintf(stderr, "    -m     Use merge sort\n");
    fprintf(stderr, "    -q     Use quick sort\n");
    fprintf(stderr, "    -n     Compare as numbers\n");
    fprintf(stderr, "\nBy default lsort uses selection sort and compares as strings.\n");
    exit(status);
}

/* Main Execution */

int	main(int argc, char *argv[]) {
    // TODO: Parse command-line options
    // TODO: Read input, sort, and dump
    return EXIT_SUCCESS;
}
