/* node.c: Node Structure */

#include "ds/node.h"

#include <string.h>

/* Functions */

/**
 * Create a Node structure.
 *
 * @param   data    String.
 * @param   next    Pointer to next Node structure.
 * @return  Pointer to a new Node structure (must be deleted later).
 **/
Node *	node_create(char *data, Node *next) {
    // TODO
    return NULL;
}

/**
 * Delete Node structure and its contents.
 *
 * @param   n	    Pointer to Node structure.
 **/
void	node_delete(Node *n) {
    // TODO
}

/**
 * Compare the data of two Node structures as strings.
 *
 * @param   a	    Pointer to a pointer to a Node structure.	    
 * @param   b	    Pointer to a pointer to a Node structure.	    
 * @return  0 if a and b are equal, negative if a < b, otherwise positive if a > b.
 **/
int	node_compare_as_strings(const void *a, const void *b) {
    // TODO
    return 0;
}

/**
 * Compare the data of two Node structures as numbers (integers).
 *
 * @param   a	    Pointer to a pointer to a Node structure.	    
 * @param   b	    Pointer to a pointer to a Node structure.	    
 * @return  0 if a and b are equal, negative if a < b, otherwise positive if a > b.
 **/
int	node_compare_as_numbers(const void *a, const void *b) {
    // TODO
    return 0;
}
