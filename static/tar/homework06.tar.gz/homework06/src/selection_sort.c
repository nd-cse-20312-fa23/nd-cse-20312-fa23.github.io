/* selection_sort.c: Selection Sort */

#include "ds/sorts.h"

/* Functions */

/** 
 * Perform selection sort on the given List and order values using the
 * specified Comparison function.
 *
 * @param	l	Pointer to List structure.
 * @param	cmp	Pointer to Comparison function.
 **/
void	selection_sort(List *l, Comparison cmp) {
    // TODO
}
