/* list.c: Linked List */

#include "ds/list.h"

#include <string.h>

/* Functions */

/**
 * Allocate and initialize a new List structure.
 *
 * @return  New List structure (must be deleted later).
 **/
List *	list_create() {
    // TODO
    return NULL;
}

/** 
 * Release all the internal Nodes of the List and then the List structure
 * itself.
 *
 * @param   l	    Pointer to the List structure.
 **/
void	list_delete(List *l) {
    // TODO
}

/** 
 * Add value to back of List.
 *
 * @param   l	    Pointer to the List structure.
 * @param   s	    String value to add to List.
 **/
void	list_append(List *l, char *s) {
    // TODO
}

/**
 * Print values in List to specified stream
 * @param   l	    Pointer to the List structure.
 **/
void	list_dump(List *l, FILE *fs) {
    // TODO
}

/** 
 * Split the linked list starting at n into left and right halves of roughly
 * the same length.
 *
 * @param   n	    Pointer to the first Node structure in sequence.
 * @param   left    Pointer to the pointer to first Node structure in new left sequence.
 * @param   right   Pointer to the pointer to first Node structure in new right sequence.
 **/
void	list_split(Node *n, Node **left, Node **right) {
    // TODO
}

/** 
 * Merge the left and right linked lists into an ordered linked list using the
 * given Comparison function.
 *
 * @param   left    Pointer to first Node structure in left sequence.
 * @param   right   Pointer to first Node structure in right sequence.
 * @param   cmp	    Pointer to Comparison function.
 * @return  Pointer to first Node structure in ordered sequence.
 **/
Node *	list_merge(Node *left, Node *right, Comparison cmp) {
    // TODO
    return NULL;
}

/**
 * Allocate an array of Node structures corresponding to the Nodes in the given List.
 *
 * @param   l	    Pointer to the List structure.
 * @return  New array of Node structures (must be freed later).
 **/
Node **	list_nodes(List *l) {
    // TODO
    return NULL;
}

/**
 * Update the links of all the Node structures in given List using the Node
 * array.
 *
 *  a[i]->next = a[i + 1]
 *
 * Note: Make sure you update the head and tail of the List.
 *  
 * @param   l	    Pointer to the List structure.
 * @param   a	    Array of Node structures.
 **/
void	list_update(List *l, Node **a) {
    // TODO
}
