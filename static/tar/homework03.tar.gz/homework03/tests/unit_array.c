/* unit_array.c: Dynamic Array Unit Test */

#include "ds/array.h"

#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Constants */

/* Tests */

int test_00_array_create() {
    Array *array1 = array_create(10);
    assert(array1);
    assert(array1->capacity == 10);
    assert(array1->size     == 0);
    free(array1->data);
    free(array1);
    
    Array *array2 = array_create(0);
    assert(array2);
    assert(array2->capacity == ARRAY_DEFAULT_CAPACITY);
    assert(array2->size     == 0);
    free(array2->data);
    free(array2);
    return EXIT_SUCCESS;
}

int test_01_array_delete() {
    Array *array1 = array_create(10);
    assert(array1);
    assert(array1->capacity == 10);
    assert(array1->size     == 0);
    array_delete(array1);
    
    Array *array2 = array_create(0);
    assert(array2);
    assert(array2->capacity == ARRAY_DEFAULT_CAPACITY);
    assert(array2->size     == 0);
    array_delete(array2);
    return EXIT_SUCCESS;
}

int test_02_array_at() {
    Array *array = array_create(0);
    assert(array);
    assert(array->capacity == ARRAY_DEFAULT_CAPACITY);
    assert(array->size     == 0);
    
    for (size_t index = 0; index < ARRAY_DEFAULT_CAPACITY; index++) {
        array->data[index] = index * 2;
    }
    array->size = ARRAY_DEFAULT_CAPACITY;

    for (size_t index = 0; index < ARRAY_DEFAULT_CAPACITY; index++) {
        assert(array_at(array, index) == index * 2);
    }
    
    for (size_t index = 1; index <= ARRAY_DEFAULT_CAPACITY; index++) {
        assert(array_at(array, -index) == array->data[array->size - index]);
    }

    array_delete(array);
    return EXIT_SUCCESS;
}

int test_03_array_resize() {
    Array *array = array_create(0);
    assert(array);
    assert(array->capacity == ARRAY_DEFAULT_CAPACITY);
    assert(array->size     == 0);

    for (size_t index = 0; index < ARRAY_DEFAULT_CAPACITY; index++) {
        array->data[index] = index * 2;
    }
    array->size = ARRAY_DEFAULT_CAPACITY;
    
    array_resize(array, ARRAY_DEFAULT_CAPACITY*2);
    assert(array->capacity == ARRAY_DEFAULT_CAPACITY*2);
    assert(array->size     == ARRAY_DEFAULT_CAPACITY);
    
    for (size_t index = 0; index < ARRAY_DEFAULT_CAPACITY; index++) {
        assert(array->data[index] == index * 2);
    }

    array_resize(array, 1);
    assert(array->capacity == 1);
    assert(array->size     == 1);
    assert(array->data[0]  == 0);

    array_delete(array);
    return EXIT_SUCCESS;
}

int test_04_array_append() {
    Array *array = array_create(0);
    assert(array);
    assert(array->capacity == ARRAY_DEFAULT_CAPACITY);
    assert(array->size     == 0);

    // Append - No resize
    for (size_t index = 0; index < ARRAY_DEFAULT_CAPACITY; index++) {
        array_append(array, index);
        assert(array->capacity == ARRAY_DEFAULT_CAPACITY);
        assert(array->size     == index + 1);
    }

    // Append - Resize
    for (size_t index = 0; index < ARRAY_DEFAULT_CAPACITY; index++) {
        array_append(array, index);
        assert(array->capacity == ARRAY_DEFAULT_CAPACITY * 2);
        assert(array->size     == ARRAY_DEFAULT_CAPACITY + index + 1);
    }

    array_delete(array);
    return EXIT_SUCCESS;
}

int test_05_array_pop() {
    Array *array = array_create(0);
    assert(array);
    assert(array->capacity == ARRAY_DEFAULT_CAPACITY);
    assert(array->size     == 0);

    // Pop - front
    for (size_t index = 0; index < ARRAY_DEFAULT_CAPACITY; index++) {
        array_append(array, index);
        assert(array->capacity == ARRAY_DEFAULT_CAPACITY);
        assert(array->size     == index + 1);
    }
    
    for (size_t index = 0; index < ARRAY_DEFAULT_CAPACITY; index++) {
        assert(array_pop(array, 0) == index);
        assert(array->size         == ARRAY_DEFAULT_CAPACITY - index - 1);

        for (size_t jndex = 0; jndex < array->size; jndex++) {
            assert(array_at(array, jndex) == index + jndex + 1); 
        }
    }
    
    // Pop - back
    for (size_t index = 0; index < ARRAY_DEFAULT_CAPACITY; index++) {
        array_append(array, index);
        assert(array->capacity == ARRAY_DEFAULT_CAPACITY);
        assert(array->size     == index + 1);
    }
    
    for (size_t index = 0; index < ARRAY_DEFAULT_CAPACITY; index++) {
        assert(array_pop(array, -1) == ARRAY_DEFAULT_CAPACITY - index - 1);
        assert(array->size          == ARRAY_DEFAULT_CAPACITY - index - 1);
    }
    
    // Pop - middle
    for (size_t index = 0; index < ARRAY_DEFAULT_CAPACITY; index++) {
        array_append(array, index);
        assert(array->capacity == ARRAY_DEFAULT_CAPACITY);
        assert(array->size     == index + 1);
    }

    for (size_t index = 0; index < ARRAY_DEFAULT_CAPACITY/2; index++) {
        assert(array_pop(array, index) == index * 2);
        assert(array->size             == ARRAY_DEFAULT_CAPACITY - index - 1);
    }
    
    array_delete(array);
    return EXIT_SUCCESS;
}

/* Main Execution */

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s NUMBER\n\n", argv[0]);
        fprintf(stderr, "Where NUMBER is right of the following:\n");
        fprintf(stderr, "    0  Test array_create\n");
        fprintf(stderr, "    1  Test array_delete\n");
        fprintf(stderr, "    2  Test array_at\n");
        fprintf(stderr, "    3  Test array_resize\n");
        fprintf(stderr, "    4  Test array_append\n");
        fprintf(stderr, "    5  Test array_pop\n");
        return EXIT_FAILURE;
    }   

    int number = atoi(argv[1]);
    int status = EXIT_FAILURE;

    switch (number) {
        case 0:  status = test_00_array_create(); break;
        case 1:  status = test_01_array_delete(); break;
        case 2:  status = test_02_array_at(); break;
        case 3:  status = test_03_array_resize(); break;
        case 4:  status = test_04_array_append(); break;
        case 5:  status = test_05_array_pop(); break;
        default: fprintf(stderr, "Unknown NUMBER: %d\n", number); break;
    }
    
    return status;
}

/* vim: set sts=4 sw=4 ts=8 expandtab ft=c: */
